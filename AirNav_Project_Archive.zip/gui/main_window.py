import tkinter as tk
from tkinter import ttk
import threading
from gestures.detector import find_hand_landmarks
from gestures.controller import apply_actions
import cv2

CAM_WIDTH, CAM_HEIGHT = 640, 480

def launch_camera(selected_mode, status_label):
    def camera_loop():
        cap = cv2.VideoCapture(0)
        cap.set(3, CAM_WIDTH)
        cap.set(4, CAM_HEIGHT)

        while cap.isOpened():
            ret, frame = cap.read()
            if not ret:
                continue
            landmarks = find_hand_landmarks(frame)
            apply_actions(landmarks, selected_mode.get())

            cv2.imshow("Gesture Virtual Mouse", frame)
            if cv2.waitKey(1) & 0xFF == 27:
                break

        cap.release()
        cv2.destroyAllWindows()
        status_label.config(text="Status: Idle", fg="black")

    status_label.config(text=f"Mode: {selected_mode.get()} (running)", fg="green")
    threading.Thread(target=camera_loop, daemon=True).start()

def build_gui():
    root = tk.Tk()
    root.title("Gesture Virtual Mouse")
    root.geometry("720x880")
    root.configure(bg="#E3F2FD")

    tk.Label(root, text="🖐 Gesture Virtual Mouse", font=("Helvetica", 24, "bold italic"), fg="#0D47A1", bg="#E3F2FD").pack(pady=20)

    mode_var = tk.StringVar(value="Mouse")
    mode_list = ["Mouse", "Scroll", "Volume", "Brightness", "All"]

    frame_mode = tk.Frame(root, bg="#E3F2FD")
    tk.Label(frame_mode, text="Select Mode:", font=("Helvetica", 12), bg="#E3F2FD").pack(side=tk.LEFT)
    ttk.Combobox(frame_mode, textvariable=mode_var, values=mode_list, width=20, state="readonly").pack(side=tk.LEFT, padx=10)
    frame_mode.pack(pady=10)

    status = tk.Label(root, text="Status: Idle", font=("Helvetica", 12), bg="#E3F2FD")
    status.pack(pady=5)

    tk.Button(root, text="▶ Start", command=lambda: launch_camera(mode_var, status), width=28, height=2, font=("Helvetica", 14, "bold"), bg="#1976D2", fg="white").pack(pady=20)

    tk.Button(root, text="❌ Exit", command=root.quit, width=20, font=("Helvetica",12), bg="#C62828", fg="white").pack(pady=30)

    root.mainloop()
