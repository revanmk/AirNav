import pyautogui
import numpy as np
from math import hypot

prev_scroll_y = None

def control_scroll(landmarks):
    global prev_scroll_y
    x1, y1 = landmarks[4][1:]
    x2, y2 = landmarks[8][1:]

    if hypot(x2 - x1, y2 - y1) < 40:
        prev_scroll_y = None
        return

    if prev_scroll_y is None:
        prev_scroll_y = y2
        return

    dy = y2 - prev_scroll_y
    if abs(dy) > 15:
        pyautogui.scroll(int(-np.sign(dy) * 3))
        prev_scroll_y = y2
