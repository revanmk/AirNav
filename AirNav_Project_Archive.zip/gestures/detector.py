import cv2
import mediapipe as mp

mp_hands = mp.solutions.hands
mp_drawing = mp.solutions.drawing_utils
hands = mp_hands.Hands(max_num_hands=1)

def find_hand_landmarks(img):
    img_rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    res = hands.process(img_rgb)
    landmarks = []
    if res.multi_hand_landmarks:
        for hand in res.multi_hand_landmarks:
            for idx, lm in enumerate(hand.landmark):
                h, w, _ = img.shape
                landmarks.append((idx, int(lm.x * w), int(lm.y * h)))
            mp_drawing.draw_landmarks(img, hand, mp_hands.HAND_CONNECTIONS)
    return landmarks
