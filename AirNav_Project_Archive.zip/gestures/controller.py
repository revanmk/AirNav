from gestures.mouse_control import control_mouse
from gestures.scroll_control import control_scroll
from gestures.volume_control import control_volume
from gestures.brightness_control import control_brightness

def apply_actions(landmarks, mode):
    if len(landmarks) < 21:
        return

    if mode in ("Mouse", "All"):
        control_mouse(landmarks)
    if mode in ("Scroll", "All"):
        control_scroll(landmarks)
    if mode in ("Volume", "All"):
        control_volume(landmarks)
    if mode in ("Brightness", "All"):
        control_brightness(landmarks)
