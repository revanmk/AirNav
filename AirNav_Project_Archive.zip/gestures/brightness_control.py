import screen_brightness_control as sbc
import numpy as np
from math import hypot

def control_brightness(landmarks):
    x3, y3 = landmarks[12][1:]
    x4, y4 = landmarks[16][1:]
    bri = np.interp(hypot(x3 - x4, y3 - y4), [20,150], [0,100])
    sbc.set_brightness(int(bri))
