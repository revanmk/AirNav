from ctypes import cast, POINTER
from comtypes import CLSCTX_ALL
from pycaw.pycaw import AudioUtilities, IAudioEndpointVolume
import numpy as np
from math import hypot

devices  = AudioUtilities.GetSpeakers()
iface    = devices.Activate(IAudioEndpointVolume._iid_, CLSCTX_ALL, None)
volume_i = cast(iface, POINTER(IAudioEndpointVolume))
min_vol, max_vol = volume_i.GetVolumeRange()[0:2]

def control_volume(landmarks):
    x1, y1 = landmarks[4][1:]
    x4, y4 = landmarks[16][1:]
    vol = np.interp(hypot(x1 - x4, y1 - y4), [20,150], [min_vol, max_vol])
    volume_i.SetMasterVolumeLevel(vol, None)
