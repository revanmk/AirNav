import pyautogui
import numpy as np
from math import hypot

CAM_WIDTH, CAM_HEIGHT = 640, 480

def control_mouse(landmarks):
    x1, y1 = landmarks[4][1:]
    x2, y2 = landmarks[8][1:]
    x3, y3 = landmarks[12][1:]

    sw, sh = pyautogui.size()
    pyautogui.moveTo(np.interp(x2, (0, CAM_WIDTH), (sw, 0)),  # Corrected inversion
                     np.interp(y2, (0, CAM_HEIGHT), (0, sh)), duration=0.05)

    if hypot(x2 - x1, y2 - y1) < 30:
        pyautogui.click()
    if hypot(x3 - x1, y3 - y1) < 30:
        pyautogui.click(button='right')
    if hypot(x3 - x2, y3 - y2) < 30:
        pyautogui.mouseDown()
    else:
        pyautogui.mouseUp()
