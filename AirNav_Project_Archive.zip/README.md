# Gesture Virtual Mouse

This is a modularized team project that uses hand gestures for controlling mouse, volume, brightness, and scrolling. Built with OpenCV, MediaPipe, Tkinter, and PyAutoGUI.
