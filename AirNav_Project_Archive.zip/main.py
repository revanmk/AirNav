from gui.main_window import build_gui

if __name__ == '__main__':
    build_gui()
